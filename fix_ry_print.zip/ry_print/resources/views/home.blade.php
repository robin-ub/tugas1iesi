<!DOCTYPE html>
<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        <style>
            .grab-hand{
                cursor:pointer;
            }

            .bg-orange{
                background-color: #ff7732;
            }

            .btn-orange{
                background-color: #ff7732;
                color: #fff;
            }

            .btn-orange:hover{
                background-color: #fff;
                border: solid 1px #ff7732;
                color: #ff7732;
            }
        </style>
    </head>
    <body>
    @include('components.navbar')
    <div class="row" style="padding-top: 120px;padding-bottom: 120px;background-image: url( '{{ asset('bg-home.svg') }}' );background-repeat: no-repeat;background-size: 100% 1500px">
        <div class="col-2"></div>
        <div class="col-8 p-4">
            <div class="row pb-3">
                <div class="col-12 text-center">
                    <h1>MODERN CONTACTLESSS<br>PRINTING SOLUTION</h1>
                </div>
            </div>
            <div class="row pb-1">
                <div class="col-12 text-justify">
                    <p>
                        RY-Print merupakan sebuah  jasa yang berupa layanan percetakan melalui sebuah sistem. Sistem ini merupakan sebuah inovasi teknologi berupa printer box portable. Printer box portable ini memungkinkan Anda untuk mencetak dokumen dengan mudah dan efisien tanpa memerlukan manual task dari manusia.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-12 d-flex justify-content-center">
                    <a href="identitas" class="btn btn-orange">Mulai Cetak</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row text-white">
        <div class="col-12">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-8 p-3 d-flex justify-content-center">
                    Bagaimana cara Printer Box ini bekerja?
                </div>
            </div>
            <div class="row p-2 bg-orange text-center">
                <div class="col-4 p-4 border-white border-right">
                    <i class="bi bi-qr-code" style="font-size: 48pt"></i>
                    <h3>Scan QR-Code</h3>
                    <p>Scan QR-Code yang ada pada printer box dan kamu akan langsung diarahkan  ke page RY-Print!</p>
                </div>
                <div class="col-4 p-4 border-white border-right">
                    <i class="bi bi-cloud-upload-fill" style="font-size: 48pt"></i>
                    <h3>Upload File</h3>
                    <p>Setelah melakukan pendataan singkat, upload file-mu dan tunggu hingga analisis file selesai.</p>
                </div>
                <div class="col-4 p-4">
                    <i class="bi bi-cash-coin" style="font-size: 48pt"></i>
                    <h3>Bayar</h3>
                    <p>Setelah analisis dan kalkulasi file selesai, pilih metode pembayran yang kamu inginkan. Setelah proses pembayaran selesai, filemu akan langsung tercetak!</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row p-2">
        <div class="col-8 p-5">
            <h2 class="pb-5">Tunggu apalagi?</h2>
            <p class="pb-4">Yuk, rasakan pengalaman mencetak dokumen tanpa melakukan kontak dengan seseorang dan anti ribet. Langsung upload dokumenmu sekarang!</p>
            <a href="identitas" class="btn btn-orange">Mulai Cetak</a>
        </div>
        <div class="col-4 pl-4">
            <img width="456" height="auto" src="{{ asset('icon.png') }}" alt="Icon">
        </div>
    </div>
    @include('components.footer')
    </body>
</html>
