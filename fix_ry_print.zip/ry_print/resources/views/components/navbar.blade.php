<div class="row">
    <div class="col-4">
        <a href="/" class="text-dark text-decoration-none"><h3 class="p-3">RY <span class="text-danger">PRINT</span></h3></a>
    </div>
    <div class="col-4 d-flex justify-content-center">
        <nav class="navbar navbar-expand-lg navbar-white bg-white p-3">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item pr-3">
                    <a class="nav-link text-secondary" href="identitas">Cetak Dokumen</a>
                </li>
                <li class="nav-item pr-3">
                    <a class="nav-link text-secondary" href="#">Lokasi Printer</a>
                </li>
                <li class="nav-item pr-3">
                    <a class="nav-link text-secondary" href="#">FAQ</a>
                </li>
            </ul>
        </nav>
    </div>
    <div class="col-4">
    </div>
</div>
