<div class="row p-5 bg-orange">
    <div class="col-9">
        <a href="/" class="text-dark text-decoration-none"><h3 class="p-3">RY <span class="text-danger">PRINT</span></h3></a>
    </div>
    <div class="col-3">
        <div class="row">
            <div class="col-6">
                <a class="text-white" href="identitas">Cetak Dokumen</a>
                <br>
                <a class="text-white" href="#">Lokasi Printer</a>
                <br>
                <a class="text-white" href="#">FAQ</a>
            </div>
            <div class="col-6">

            </div>
        </div>
    </div>
</div>
