@extends('layouts.app')

@section('content')
    <div class="row p-5 m-5">
        <div class="col-1"></div>
        <div class="col-10 shadow">
            <div class="row text-center">
                <div class="col-4 p-4 border-orange border-bottom">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">1</span> Identitas</h4>
                </div>
                <div class="col-4 p-4 border-orange border-bottom">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">2</span> Unggah File</h4>
                </div>
                <div class="col-4 p-4">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">3</span> Pembayaran</h4>
                </div>
            </div>
            <div class="row py-3 px-5">
                <div class="col-12 px-4 py-2">
                    <div class="row mb-2">
                        <div class="col-8">
                            <label for="fileControl"><b>Unggah File</b></label>
                        </div>
                        <div class="col-4 text-right">
                            <button id="add-file" class="btn btn-sm text-secondary d-none"><b><i class="bi-plus"></i> Tambah File</b></button>
                        </div>
                    </div>
                    <div class="row px-3 py-5 text-center shadow mx-1 grab-hand rounded" style="background-color: #f8f9fa;color: #d1d7dd;" id="upload-trigger">
                        <div class="col-12 px-3 py-5">
                            <i class="bi bi-upload" style="font-size: 36pt"></i>
                            <p>Klik disini untuk menggunggah file</p>
                        </div>
                    </div>
                    <form>
                        <div class="form-group">
                            <input type="file" class="form-control-file d-none" id="fileControl">
                        </div>
                        <div class="row py-2 mx-1 d-none" id="file-manager" style="background-color: #f8f9fa">
                            <div class="col-12">
                                <div class="row pt-1">
                                    <div class="col-9">
                                        <p><i class="bi bi-file-earmark"></i> Artikel Bimbingan.pdf</p>
                                    </div>
                                    <div class="col-3 d-flex justify-content-end">
                                        <button type="button" class="btn d-inline"><b><i class="bi bi-pencil-square"></i></b></button>
                                        <button type="button" class="btn"><b><i class="bi bi-trash"></i></b></button>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                         <table class="table">
                                             <tr>
                                                 <td colspan="2">Warna Cetak</td>
                                                 <td><b>Warna</b></td>
                                             </tr>
                                             <tr>
                                                 <td colspan="2">Jumlah Halaman</td>
                                                 <td><b>20 Lembar</b></td>
                                             </tr>
                                             <tr>
                                                 <td>Detail Harga</td>
                                                 <td>20 x Rp 1.000,00</td>
                                                 <td><b>Rp 20.000,00</b></td>
                                             </tr>
                                         </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="next-button" class="pt-4 text-right d-none">
                            <a href="/" class="btn btn-orange">Batalkan</a>
                            <a href="pembayaran" class="btn btn-orange">Selanjutnya</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        const fileControl = document.getElementById('fileControl');
        const fileManager = document.getElementById('file-manager');
        const addFile = document.getElementById('add-file');
        const nextButton = document.getElementById('next-button');
        const uploadTrigger = document.getElementById('upload-trigger');

        uploadTrigger.addEventListener('click', function () {
            fileControl.click();
        });

        fileControl.addEventListener('change', function () {
            if (fileControl.files.length > 0) {
                fileManager.classList.remove('d-none');
                addFile.classList.remove('d-none');
                nextButton.classList.remove('d-none');
                fileControl.classList.add('d-none');
                uploadTrigger.classList.add('d-none')
            } else {
                fileManager.classList.add('d-none');
                addFile.classList.remove('d-none');
                nextButton.classList.remove('d-none');
            }
        });
    </script>
@endsection
