<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .grab-hand{
            cursor:pointer;
        }

        .bg-orange{
            background-color: #ff7732;
        }

        .btn-orange{
            background-color: #ff7732;
            color: #fff;
        }

        .btn-orange:hover{
            background-color: #fff;
            border: solid 1px #ff7732;
            color: #ff7732;
        }
    </style>
</head>
<body>
@include('components.navbar')
@include('components.tagline')

@yield('content')

@include('components.footer')
</body>
</html>
