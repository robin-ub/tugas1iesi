@extends('layouts.app')

@section('content')
    <div class="row p-5 m-5">
        <div class="col-1"></div>
        <div class="col-10 shadow">
            <div class="row text-center">
                <div class="col-4 p-4 border-orange border-bottom">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">1</span> Identitas</h4>
                </div>
                <div class="col-4 p-4 border-orange border-bottom">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">2</span> Unggah File</h4>
                </div>
                <div class="col-4 p-4 border-orange border-bottom">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">3</span> Pembayaran</h4>
                </div>
            </div>
            <div id="invoice" class="row py-3 px-5 d-none">
                <div class="col-12 px-4 py-2">
                    <div>
                        <h3>DETAIL TRANSAKSI</h3>
                    </div>
                    <div class="px-2">
                        <p><b>Nomor Transaksi</b><br>#19357274679</p>

                        <p><b>Tanggal Transaksi</b><br>18 Mei 2023</p>
                    </div>
                    <hr>
                    <div>
                        <h5>IDENTITAS</h5>
                    </div>
                    <div class="px-2">
                        <p><b>Nama</b><br>Valerie Laetici</p>

                        <p><b>Nomor HP</b><br>087534511056</p>

                        <p><b>Jenis</b><br>Pribadi</p>

                        <p><b>E-mail</b><br>valerielae@gmail.com</p>
                    </div>
                    <hr>
                    <div>
                        <h5>PEMBAYARAN</h5>
                    </div>
                    <div class="px-2">
                        <table class="w-100">
                            <tr>
                                <td style="width: 65%;">Artikel Bimbingan.pdf</td>
                                <td class="border-bottom border-dark text-right">Rp 20.000,00</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td class="text-right"><b>Total Pembayaran: Rp 20.000,00</b></td>
                            </tr>
                        </table>
                    </div>
                    <div class="mt-4 pt-3 text-center">
                        <a href="unggah-file" class="btn btn-orange w-25">Bayar</a>
                    </div>
                </div>
            </div>
            <div id="payment-method">
                <div onclick="showPayment('qris', 'qris-trigger')" class="row py-2" style="background-color: #f8f9fa">
                    <div class="col-12 py-1">
                        <div class="row grab-hand">
                            <div class="col-11">
                                <h4>QRIS</h4>
                            </div>
                            <div class="col-1 text-right mt-1">
                                <i id="qris-trigger" class="bi bi-chevron-down p-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="qris" class="row py-2 d-none">
                    <div class="col-12 p-5 text-center">
                        <h5>Silakan scan  QR Code Pembayaran di bawah ini :</h5>
                        <img width="200" height="auto" src="https://img.freepik.com/premium-vector/qr-code-sample-smartphone-scanning-qr-code-icon-flat-design-stock-vector-illustration_550395-108.jpg" alt="QR-Payment">
                        <h5>00:05:00</h5>
                        <a href="pembayaran-berhasil" class="btn btn-orange">Ya, Saya sudah membayar</a>
                    </div>
                </div>
                <div onclick="showWallet('wallet', 'wallet-trigger')" class="row py-2" style="background-color: #f8f9fa">
                    <div class="col-12 py-1">
                        <div class="row grab-hand">
                            <div class="col-11">
                                <h4>E-Wallet</h4>
                            </div>
                            <div class="col-1 text-right mt-1">
                                <i id="wallet-trigger" class="bi bi-chevron-down p-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="wallet" class="row py-2 d-none">
                    <div class="col-12 p-5 text-center">
                        <h5 class="mb-4 pb-2">Klik di bawah ini sesuai dengan metode pembayaran Anda :</h5>
                        <div class="border border-dark p-4 mb-3" style="border-radius: 20px;">
                            <a class="w-100" href="pembayaran-berhasil"><img width="auto" height="70" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo_ovo_purple.svg/2560px-Logo_ovo_purple.svg.png" alt="ovo"></a>
                        </div>
                        <div class="border border-dark p-4 mb-3" style="border-radius: 20px;">
                            <a class="w-100" href="pembayaran-berhasil"><img width="auto" height="70" src="https://upload.wikimedia.org/wikipedia/commons/7/72/Logo_dana_blue.svg" alt="ovo"></a>
                        </div>
                        <div class="border border-dark p-4 mb-3" style="border-radius: 20px;">
                            <a class="w-100" href="pembayaran-berhasil"><img width="auto" height="70" src="https://upload.wikimedia.org/wikipedia/commons/8/86/Gopay_logo.svg" alt="ovo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        let qrisClicked = false;
        let walletClicked = false;

        function showPayment(contentId, triggerId)
        {
            const content = document.getElementById(contentId);
            const trigger = document.getElementById(triggerId);

            if(walletClicked){
                showWallet('wallet', 'wallet-trigger');
            }

            if (!qrisClicked) {
                content.classList.remove('d-none');
                trigger.classList.remove('bi-chevron-down');
                trigger.classList.add('bi-chevron-up');
                qrisClicked = true;
            } else {
                content.classList.add('d-none');
                trigger.classList.remove('bi-chevron-up');
                trigger.classList.add('bi-chevron-down');
                qrisClicked = false;
            }
        }

        function showWallet(contentId, triggerId)
        {
            const content = document.getElementById(contentId);
            const trigger = document.getElementById(triggerId);

            if(qrisClicked){
                showPayment('qris', 'qris-trigger');
            }

            if (!walletClicked) {
                content.classList.remove('d-none');
                trigger.classList.remove('bi-chevron-down');
                trigger.classList.add('bi-chevron-up');
                walletClicked = true;
            } else {
                content.classList.add('d-none');
                trigger.classList.remove('bi-chevron-up');
                trigger.classList.add('bi-chevron-down');
                walletClicked = false;
            }
        }
    </script>
@endsection
