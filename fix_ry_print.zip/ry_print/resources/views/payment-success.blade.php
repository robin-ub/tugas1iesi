<!DOCTYPE html>
<html>
<head>
    <title>Pembayaran Berhasil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .grab-hand{
            cursor:pointer;
        }

        .bg-orange{
            background-color: #ff7732;
        }

        .btn-orange{
            background-color: #ff7732;
            color: #fff;
        }

        .btn-orange:hover{
            background-color: #fff;
            border: solid 1px #ff7732;
            color: #ff7732;
        }

        .text-orange{
            color: #ff7732;
        }
    </style>
</head>
<body>
<div class="row p-5 bg-orange text-center text-white">
    <div class="col-12">
        <h2><i class="bi bi-check px-2 rounded-circle bg-success" style="font-size: 48pt"></i></h2>
        <h4>Pembayaran telah berhasil</h4>
    </div>
</div>
<div class="row p-5">
    <div class="col-1"></div>
    <div class="col-10 shadow">
        <table class="table">
            <tr>
                <td><b>Nomor Transaksi</b></td>
                <td class="text-right">#19357274679</td>
            </tr>
            <tr>
                <td><b>Metode Pembayaran</b></td>
                <td class="text-right">Gopay</td>
            </tr>
            <tr>
                <td><b>Total Pembayaran</b></td>
                <td class="text-right">Rp 20.000,00</td>
            </tr>
            <tr>
                <td><b>Waktu Pembayaran</b></td>
                <td class="text-right">{{ now() }}</td>
            </tr>
        </table>
    </div>
</div>
<div class="text-center">
    <a class="btn btn-secondary p-2 w-25" href="/">Kembali</a>
    <button class="btn btn-orange p-2 w-25" data-toggle="modal" data-target="#filePrint">Print file-mu</button>
</div>

<div class="modal fade" id="filePrint" tabindex="-1" role="dialog" aria-labelledby="filePrintLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body text-center p-4">
                <i class="bi bi-check px-2 rounded-circle bg-success text-white" style="font-size: 48pt"></i>
                <h4>Printing telah berhasil</h4>
                <p class="text-orange">Berikan feedback-mu..</p>
            </div>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
