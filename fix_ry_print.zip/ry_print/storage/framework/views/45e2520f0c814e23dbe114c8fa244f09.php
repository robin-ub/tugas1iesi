<?php $__env->startSection('content'); ?>
    <div class="row p-5 m-5">
        <div class="col-1"></div>
        <div class="col-10 shadow">
            <div class="row text-center">
                <div class="col-4 p-4 border-orange border-bottom">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">1</span> Identitas</h4>
                </div>
                <div class="col-4 p-4">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">2</span> Unggah File</h4>
                </div>
                <div class="col-4 p-4">
                    <h4><span class="text-white px-3 py-1 rounded-circle bg-orange">3</span> Pembayaran</h4>
                </div>
            </div>
            <div class="row py-3 px-5">
                <div class="col-12 px-4 py-2">
                    <form>
                        <div class="form-group">
                            <label for="name"><b>Nama</b></label>
                            <input type="text" class="form-control" id="name"placeholder="Masukan Nama" required>
                        </div>
                        <div class="form-group">
                            <label for="phone"><b>Nomor HP</b></label>
                            <input type="tel" class="form-control" id="phone" placeholder="Masukan Nomor HP" required>
                        </div>
                        <div class="form-group">
                            <label for="jenis"><b>Jenis</b></label>
                            <select id="jenis" class="form-control" required>
                                <option hidden="hidden" readonly="true">Pilih</option>
                                <option value="organisasi">Organisasi</option>
                                <option value="pribadi">Pribadi</option>
                            </select>
                        </div>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="receipt" onclick="showEmail()">
                            <label class="form-check-label" for="receipt">Apakah Anda ingin dikirim receipt?</label>
                        </div>
                        <div class="form-group mt-2 d-none" id="email-form">
                            <label for="email"><b>Email</b></label>
                            <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Masukan E-mail Anda">
                        </div>
                        <div class="text-right">
                            <a href="unggah-file" class="btn btn-orange">Selanjutnya</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        function showEmail()
        {
            const emailForm = document.getElementById('email-form');
            const receiptCheckbox = document.getElementById('receipt');

            receiptCheckbox.addEventListener('change', function () {
                if (receiptCheckbox.checked) {
                    emailForm.classList.remove('d-none');
                } else {
                    emailForm.classList.add('d-none');
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\ry_print\resources\views/identity.blade.php ENDPATH**/ ?>