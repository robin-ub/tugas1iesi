<div class="row p-5 bg-orange text-center text-white">
    <div class="col-12">
        <h2>CETAK DOKUMEN</h2>
        <p>Cetak dengan Mudah dan Efisien Melalui Inovasi Printer Box Portable</p>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Documents\ry_print\resources\views/components/tagline.blade.php ENDPATH**/ ?>